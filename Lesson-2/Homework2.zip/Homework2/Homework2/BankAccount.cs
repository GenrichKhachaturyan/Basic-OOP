﻿using System;


namespace Homework2
{

    


    public class BankAccount
	{
        private long accountNumber; 
		private decimal balance;
        private int typeAccount;

     


        public long AccountNumber
        {
            get
            {
                return this.accountNumber;
            }
            set
            {
                if(value > 0)
                {
                    this.accountNumber = value;
                }
                else
                {
                    throw new Exception("Account number cannot be less than zero");
                }
            }
        }

        public decimal Balance
        {
            get
            {
                return this.balance;
            }
            set
            {
                this.balance = value;
            }
        }

        public int TypeAccount
        {
            get
            {
                return this.typeAccount;
            }
            set
            {
                if(value < 0|| value > 3)
                {
                    Console.WriteLine("Incorrect input values");
                }
                else
                {
                    this.typeAccount = value;
                }
            }
        }














































        public BankAccount(decimal balance)
        {
            SetValueAccountNumber();

            if(balance > 0)
            {
                this.balance = balance;
            }
            else
            {
                Console.WriteLine("Balance cannot be less than zero");
            }
        }



        public BankAccount(int typeAccount)
        {
            SetValueAccountNumber();

            if(typeAccount > 0 && typeAccount < 4)
            {
                this.typeAccount = typeAccount;
            }
            else
            {
                Console.WriteLine("Incorrect input values");
            }
        }

        public BankAccount()
        {

        }


        /// <summary>
        /// Установка уникального значения для каждого аккаунта
        /// </summary>
        public void SetValueAccountNumber()
        {
            //uniqueNumberAccount ++;
            
        }
     


		public void GetInfo()
        {
			//Console.Clear();
            Console.WriteLine("=================================");
            Console.Write("Current account : ");
            GetTypeAccout(typeAccount);
            Console.WriteLine($"Number account : {accountNumber}");
            Console.WriteLine($"Balance account : {balance}");
            Console.WriteLine("=================================");
        }




        public void GetTypeAccout(int num)
        {
            switch (num)
            {
                case 1:
                    {
                        Console.WriteLine("Budget account");
                    }
                    break;
                case 2:
                    {
                        Console.WriteLine("Currency account");
                    }
                    break;
                case 3:
                    {
                        Console.WriteLine("Savings account");
                    }
                    break;
                default:
                    Console.WriteLine("Unrecognized account");
                    break;

            }
           
           
              
        }
        
	}
		
}

