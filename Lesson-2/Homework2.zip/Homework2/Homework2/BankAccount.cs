﻿using System;


namespace Homework2
{
	public class BankAccount
	{
		private long accountNumber;
		private decimal balance;
        private int typeAccount;
        

		public void SetInfo()
        {
            bool check = false;//check value number account
            bool check2 = false;//check balance value
            bool check3 = false;

            do
            {
                Console.Write("Enter number account: ");
                try
                {
                    if (long.TryParse(Console.ReadLine(),out long numAcc))
                    {
                        if(numAcc <= 0)
                        {
                            throw new Exception("Account number cannot be less than or equal to 0");
                        }
                        else
                        {
                            this.accountNumber = numAcc;
                            check = true;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Incorrect input values");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            } while (!check);

            do
            {
                Console.Write("Enter your balance: ");
                if (decimal.TryParse(Console.ReadLine(), out decimal balanc))
                {
                    if(balanc < 0)
                    {
                        Console.WriteLine("Balance cannot be less than zero");
                    }
                    else
                    {
                        this.balance = balanc;
                        check2 = true;
                    }
                }
                else
                {
                    Console.WriteLine("Incorrect input values");
                }

            } while (!check2);


            do
            {
                Console.Write("=========================================\n");
                Console.WriteLine("Chooice Type Account: 1)Budget account");
                Console.WriteLine("                      2)Currency account");
                Console.WriteLine("                      3)Savings account");
                Console.Write("=========================================\n");
                Console.Write("Enter number account: ");

                if (int.TryParse(Console.ReadLine(), out int numTypeAcc))
                {
                    GetTypeAccout(numTypeAcc);
                    check3 = true;
                }
                else
                {
                    Console.WriteLine("Incorrect input values");
                    Console.ReadKey(true);
                    Console.Clear();
                }

                this.typeAccount = numTypeAcc;
            } while (!check3);
		}


		public void GetInfo()
        {
			Console.Clear();
            Console.WriteLine("=================================");
            Console.Write("Current account : ");
            GetTypeAccout(typeAccount);
            Console.WriteLine($"Number account : {accountNumber}");
            Console.WriteLine($"Balance account : {balance}");
            Console.WriteLine("=================================");
        }




        public void GetTypeAccout(int num)
        {
            switch (num)
            {
                case 1:
                    {
                        Console.WriteLine("Budget account");
                    }
                    break;
                case 2:
                    {
                        Console.WriteLine("Currency account");
                    }
                    break;
                case 3:
                    {
                        Console.WriteLine("Savings account");
                    }
                    break;
                default:
                    Console.WriteLine("Unrecognized account");
                    break;

            }
           
           
              
        }
        
	}
		
}

