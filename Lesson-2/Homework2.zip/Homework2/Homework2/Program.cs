﻿using System;

namespace Homework2
{
    public class Program
    {
        public static void Main(string [] args)
        {
            BankAccount myFirstAccount = new BankAccount();

            myFirstAccount.SetInfo();
            myFirstAccount.GetInfo();


            BankAccount mySecondAccount = new BankAccount();

            mySecondAccount.SetInfo();
            mySecondAccount.GetInfo();


            BankAccount myThirdAccount = new BankAccount();

            myThirdAccount.SetInfo();
            myThirdAccount.GetInfo();


        }
    }
}