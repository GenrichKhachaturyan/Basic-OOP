﻿using System;

namespace Homework2
{
    public class Program
    {
        public static void Main(string [] args)
        {
            BankAccount myAccount = new BankAccount();

            myAccount.AccountNumber = 546040003201;
            myAccount.Balance = 2456;
            myAccount.TypeAccount = 2;
            
            Console.WriteLine($"Number your account : {myAccount.AccountNumber}");
            Console.WriteLine($"Balance your account : {myAccount.Balance}");
            Console.WriteLine($"Type your account : {myAccount.TypeAccount}");



        }
    }
}