﻿using System;

namespace Homework2
{
    public class Program
    {
        public static void Main(string [] args)
        {
            BankAccount myAccount = new BankAccount();

            myAccount.SetInfo();
            myAccount.GetInfo();
        }
    }
}