﻿using System;

namespace Homework2
{
    public class Program
    {
        public static void Main(string [] args)
        {
            BankAccount myFirstAccount = new BankAccount(5000m);

            myFirstAccount.GetInfo();

            BankAccount mySecondAccount = new BankAccount(2);

            mySecondAccount.GetInfo();



        }
    }
}